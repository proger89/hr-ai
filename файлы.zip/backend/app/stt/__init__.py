# makes generated modules importable as app.stt.recognitionv2_pb2*

